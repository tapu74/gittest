<?php
//database server
define('DB_SERVER', "localhost");

//database login name
define('DB_USER', "username");
//database login password
define('DB_PASS', "password");

//database name
define('DB_DATABASE', "username_mydata");

//smart to define your table names also
define('TABLE_USERS', "users");
define('TABLE_NEWS', "news");

?>